## DashControl v0.1.1

**Released:** 2026-07-02
**Previous:** v0.1.0



### What's included
- All tests passing across Python 3.9, 3.10, 3.11, 3.12
- API documentation regenerated (see `docs/api/`)
- Published to PyPI and Databricks Marketplace

### Install
```bash
pip install dash-control==0.1.1
```

### Quick Start (Databricks notebook)
```python
%pip install dash-control==0.1.1
import dashcontrol
dashcontrol.launch()
```
